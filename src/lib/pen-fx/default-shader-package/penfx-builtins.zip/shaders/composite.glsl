
  precision highp float;
  varying vec2 v_uv;
  uniform sampler2D u_base;
  uniform sampler2D u_effect;
  uniform int u_blend;
  uniform float u_opacity;

  vec3 straightColor(vec4 p) {
    return p.a > 0.00001 ? p.rgb / p.a : vec3(0.0);
  }

  void main() {
    float opacity = clamp(u_opacity, 0.0, 1.0);
    vec4 basePixel = texture2D(u_base, v_uv);
    vec4 effectPixel = texture2D(u_effect, v_uv);
    if (u_blend == 0) {
      gl_FragColor = mix(basePixel, effectPixel, opacity);
      return;
    }
    vec3 b = straightColor(basePixel);
    vec3 e = straightColor(effectPixel);
    vec3 c;
    if (u_blend == 1) {
      c = b + e;
    } else if (u_blend == 2) {
      c = b * e;
    } else if (u_blend == 3) {
      c = vec3(1.0) - (vec3(1.0) - b) * (vec3(1.0) - e);
    } else if (u_blend == 4) {
      c = mix(2.0 * b * e, vec3(1.0) - 2.0 * (vec3(1.0) - b) * (vec3(1.0) - e), step(vec3(0.5), b));
    } else if (u_blend == 5) {
      c = min(b, e);
    } else if (u_blend == 6) {
      c = max(b, e);
    } else {
      c = min(vec3(1.0), b / max(vec3(1.0) - e, vec3(0.0039215686)));
    }
    c = mix(b, c, opacity);
    float alpha = mix(basePixel.a, max(basePixel.a, effectPixel.a), opacity);
    gl_FragColor = vec4(clamp(c, 0.0, 1.0) * alpha, alpha);
  }
